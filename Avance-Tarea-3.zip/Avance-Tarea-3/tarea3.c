#include <stdio.h>
#include <stdlib.h>
#include "tdas/stack.h"
#include "tdas/list.h"
#include "tdas/heap.h"
#include "tdas/extra.h"
#include <string.h>
#include <time.h>

#define arriba 1
#define abajo 2
#define izquierda 3
#define derecha 4

// grafo implicito
typedef struct {
    int maze[N][N]; // Matriz NxN que representa el tablero
    int x;    // Posición x del agente
    int y;    // Posición y del agente
    int steps; // Pasos realizados hasta la posición actual
    List* actions; //Secuencia de movimientos para llegar al estado
} State;

int distancia_L1(State* state) {
    return abs(state->x - (N-1)) + abs(state->y - (N-1));
}

void imprimirEstado(const State *estado) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (estado->x==i && estado->y==j) printf(" A ");
            else if (i == 0 && j == 0) printf(" I "); 
            else if (i == N-1 && j == N-1) printf(" M ");
            else if (estado->maze[i][j] == 0)
                printf(" . "); // Imprime un espacio en blanco para el espacio vacío
            else
                printf("[X]");
        }
        printf("\n");
    }
}

int isFinal (State* estadoActual){
    return (estadoActual->x == N - 1 && estadoActual->y == N - 1);
}

State crearEstadoInicial(int dificultad){
    State estado;
     // Copiar el laberinto generado al estado
    generate_maze(estado.maze,  dificultad);
    estado.x = 0;
    estado.y = 0;
    estado.steps = 0;
    estado.actions = list_create();
    return estado;
}

State* transicion(State* estadoActual, int accion){
    //Nuevo estado x
    int newX = estadoActual->x;
    //Nuevo estado Y
    int newY = estadoActual->y;

    if (accion == 1) newX -= 1;
    else if (accion == 2) newX += 1;
    else if (accion == 3) newY -= 1;
    else if (accion == 4) newY += 1;

    if (newX < 0 || newX >= N || newY < 0 || newY >= N || estadoActual->maze[newX][newY] == 1){
        return NULL;
    }

    State *nuevoEstado = (State*)malloc(sizeof(State));

    for (int x = 0; x < N; x++){
        for (int y = 0; y < N; y++){
            nuevoEstado->maze[x][y] = estadoActual->maze[x][y];
        }
    }
    nuevoEstado->x = newX;
    nuevoEstado->y = newY;
    nuevoEstado->steps = estadoActual->steps + 1;
    
    nuevoEstado->actions = list_create();

    if (estadoActual->actions != NULL){
        int *pasoPrevio = list_first(estadoActual->actions);
        while(pasoPrevio != NULL){
            int *copiaPaso = (int*)malloc(sizeof(int)*2);
            copiaPaso[0] = pasoPrevio[0];
            copiaPaso[1] = pasoPrevio[1];
            list_pushBack(nuevoEstado->actions, copiaPaso);
            pasoPrevio = list_next(estadoActual->actions);
        }
    }

    int* pasoActual = (int*)malloc(sizeof(int)*2);
    pasoActual[0] = newX;
    pasoActual[1] = newY;
    list_pushBack(nuevoEstado->actions, pasoActual);
    
    return nuevoEstado;
}

List* obtener_adyacentes(State* estadoActual){
    List* adyacentes = list_create();

    for (int accion = 1; accion <= 4; accion++){
        State* nuevoEstado = transicion(estadoActual, accion);
        if (nuevoEstado != NULL){
            list_pushBack(adyacentes, nuevoEstado);
        }
    }
    return adyacentes;
}

// Inicializa la matriz para encontrar la solucion
void iniciar_visitados(int visitados[N][N]){
    for(int x = 0; x < N; x++){
        for (int y = 0; y < N; y++){
            visitados[x][y] = 0;
        }
    }
}

// Funcion que verifica si un nodo adyacente ya fue visitado
int is_visited(int visitados[N][N], int x, int y){
    return visitados[x][y] == 1;
}

// Funcion que marca un nodo como visitado
void marcar_visitados(int visitados[N][N], int x, int y){
    visitados[x][y] = 1;
}

// Busqueda en profundidad
void dfs(State estadoInicial){
    printf("\n\n------ Busqueda en profundidad ------\n\n");

    Stack* pila = stack_create(NULL);
    int visitados[N][N];
    iniciar_visitados(visitados);

    State* inicial = (State*)malloc(sizeof(State));
    *inicial = estadoInicial;
    stack_push(pila, inicial);

    int contador = 0;

    while(stack_top(pila) != NULL){
        State* actual = (State*)stack_pop(pila);
        contador++;

        if (isFinal(actual)){
            printf("Ruta encontrada!!\n\n");
            printf("Pasos totales ruta [%d]\n", actual->steps);
            printf("Nodos procesados (vueltas) : %d\n", contador);

            printf("Inicio - - > ");

            int* pasoActual = list_first(actual->actions);
            while(pasoActual != NULL){
                printf("(%d,%d) - ", pasoActual[0], pasoActual[1]);
                pasoActual = list_next(actual->actions);
            }
            printf("- > Meta\n\n");
            while (stack_top(pila) != NULL){
                State* estadoBorrar = (State*)stack_pop(pila);
                free(estadoBorrar);
            }
            free(pila);
            return;
        }

        if (!is_visited(visitados, actual->x, actual->y)){
            marcar_visitados(visitados, actual->x, actual->y);
            List* adyacentes = obtener_adyacentes(actual);
            State* vecino = (State*)list_first(adyacentes);

            while(vecino != NULL){
                if (!is_visited(visitados, vecino->x, vecino->y)) stack_push(pila, vecino);
                else free(vecino);
                vecino = (State*)list_next(adyacentes);
            }
            free(adyacentes);
            
        }
            
        else free(actual);
    }
    
    printf("El algoritmo no encontro una ruta hacia la meta!!\n");
}

int main() {

    // AVANCE TAREA 3

    
    // Inicializador de la semilla de aleatoriedad
    srand(time(NULL));

    // Revisar readme para un ejemplo especifico del funcionamiento
    printf("\n=============================================\n");
    printf(" Avance Tarea 3: Navegacion laberinto N x N");
    printf("\n=============================================\n");

    int dificultad;

    do{
        printf("\nIngresar dificultad del laberinto (NUMERO : 0 - 100)\n");
        if(scanf("%d", &dificultad) != 1){
            while(getchar() != '\n');
            dificultad = -1;
        }
        if (dificultad < 0 || dificultad > 100) {
            printf("\nDificultad no permitida, ingresar una entre 0 - 100\n");
        }
    }while(dificultad < 0 || dificultad > 100);


    // Inicializacion del estado usando la funcion crear estado inicial
    printf("\nGeneracion del laberinto de dificultad : %d\n", dificultad);
    State estadoDePrueba = crearEstadoInicial(dificultad);

    // Visualizacion inicial del laberinto
    printf("\nLaberinto de dificultad [%d] generado!\n", dificultad);
    imprimirEstado(&estadoDePrueba);
    printf("\nDistancia de manhattan ideal (L1) a meta : %d pasos\n", distancia_L1(&estadoDePrueba));

    // Prueba de la funcion de adyacencia (grafo implicito)
    printf("\nPrueba generacion nodos adyacentes posicion actual (0,0)\n");
    List* vecinos = obtener_adyacentes(&estadoDePrueba);
    State* vecino = (State*)list_first(vecinos);

    // Se valida si el agente esta rodeado desde el inicio por error
    if (vecino == NULL)printf("[ERROR] - El agente esta rodeado de paredes al inicio\n");
    
    while(vecino != NULL){
        printf("Movimiento valido detectado -> nueva posicion : (%d, %d) | pasos acumulados : %d\n", vecino->x, vecino->y, vecino->steps);
        vecino = (State*)list_next(vecinos);
    }

    // Liberar nodos de la lista de vecinos y la lista de vecinos por completo
    list_clean(vecinos);
    free(vecinos);

    // Ejecucion del algoritmo DFS, busqueda en profundidad
    dfs(estadoDePrueba);

    return 0;
}
