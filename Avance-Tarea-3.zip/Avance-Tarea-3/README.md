## Código de Ejemplo (tarea3)
Para ejecutar el ejemplo tarea1 primero debemos compilar (en la carpeta raíz)
````
gcc tdas/*.c tarea3.c -Wno-unused-result -o tarea3
````

Y luego ejecutar:
````
./tarea3
````



Ejemplo funcionamiento funcion obtener_adyacentes:

- Matriz 5 x 5

| 0 | 0 | 1 | 0 | 0 |

| 0 | X | 0 | 1 | 0 |

| 0 | 1 | 0 | 0 | 0 |

| 0 | 0 | 0 | 0 | 0 |

| 0 | 0 | 0 | 0 | 0 |

- Estado inicial (1,1)
- Pasos iniciales 0


1. Nodo adyacente arriba valido, posicion (0,1)
2. Nodo adyacente abajo invalido
3. Nodo adyacente izquierda valido, posicion (1,0)
4. Nodo adyacente derecha valido, posicion (1, 2)